require("medvidec")
require("config.lazy")


