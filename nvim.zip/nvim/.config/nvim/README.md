keybindings:

leader = leertaste

telescope:
- syntaxhighlighting und indenting suchen und stuff

leader pf       project find    -   fuzzy finding im project
leader ps       project search  -   live grep
crtl+p          ctrl+p          -   fuzzy find im git repo

neo-tree:
- file manager tree

leader n        open/switch to file tree

lsp:
- 

shift+k (K)     <cursor muss über einem statement sein> zeigt definition an
gd              go to definition
leader ca       code actions





install remarks:

install npm packet to make mason workin
FONTS:
wget https://github.com/ryanoasis/nerd-fonts/releases/download/v3.2.1/FiraMono.zip
unzip to ~/.local/share/fonts
setup fonts in console



